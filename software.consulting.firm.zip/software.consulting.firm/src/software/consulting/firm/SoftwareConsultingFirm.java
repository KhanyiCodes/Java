/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package software.consulting.firm;

import java.util.Scanner;

/**
 *
 * @author 27662
 */
public class SoftwareConsultingFirm {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //PROMPTING FOR MOVIE RATING
        Scanner inp = new Scanner(System.in);
        System.out.println("Please enter the movie rating: ");
        String MovieRating = inp.next();
        
        //PROMPTING FOR AGE
        System.out.println("Please enter your age: ");
        double Age = inp.nextDouble();
        
        if (Age < 18)
        {
            System.out.println("Sorry,You not allowed to watch this movie ");
        }
        else if (Age >=18)
        {
            System.out.println("You are allowed to watch this movie ");
        }
     System.out.println("The movie rating is" + " " + MovieRating + " " + "and your are" + " " + Age + " " + "years old");
    }
    
}
