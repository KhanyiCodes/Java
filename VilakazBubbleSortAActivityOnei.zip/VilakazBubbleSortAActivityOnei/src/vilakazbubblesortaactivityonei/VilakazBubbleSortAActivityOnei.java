/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vilakazbubblesortaactivityonei;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Khanyi
 */
public class VilakazBubbleSortAActivityOnei {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    public static int generateMarks()
    {
        Random rnd = new Random();
        int rnd1 = rnd.nextInt(100-50)-50;
        System.out.println(rnd1);
        return rnd1;
        
    }
    public static int ArraySort()
    {
        int rnd1 = 0;
        int arrMarks[] = {rnd1};
        int temp, max, min;
        min = arrMarks[0];
        for (int k = 0; k < arrMarks.length; k++) {
            for (int z = k; z < arrMarks.length ; z++) {
                if (arrMarks[k] > arrMarks[z]) {
                    temp = arrMarks[k];
                    arrMarks[k] = arrMarks[z];
                    arrMarks[z] = temp;
                }
            }
        }
        for (int j = 0; j < arrMarks.length; j++) {
            System.out.println(arrMarks[j]);
        }
        return 0;
    }
    public static void DisplayArray()
    {
        System.out.println();
    }
}
