/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salary4employees;

import javax.swing.JOptionPane;

/**
 *
 * @author Khanyi
 */
public class Salary4Employees {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //my joptions
        String[] name = new String[4];
        double [] salary = new double[4];
        name[0] = JOptionPane.showInputDialog(null, "Enter 1st name: ");
        salary[0] = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter " + name[0]+"'s salary"));
        name[1] = JOptionPane.showInputDialog(null, "Enter 2nd name: ");
        salary[1] = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter " + name[1]+"'s salary"));
        name[2] = JOptionPane.showInputDialog(null, "Enter 3rd name: ");
        salary[2] = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter " + name[2]+"'s salary"));
        name[3] = JOptionPane.showInputDialog(null, "Enter 4th name: ");
        salary[3] = Double.parseDouble(JOptionPane.showInputDialog(null,"Enter " + name[3]+"'s salary"));
        
          
        int salary1 = 0;
        int salary2 = 0;
        int salary3 = 0;
        int salary4 = 0;
        double salary = 0;
        double tax = salary * 0.14;
        double MedAid = salary * 0.7;
        double bonus = salary * 0.10;
        double TotDed = tax + MedAid;
        double GroSal = salary + bonus;
        double NetDed = GroSal - TotDed;
        double NetSal = salary1 + salary2 + salary3 + salary4;
      
    }
    
}
