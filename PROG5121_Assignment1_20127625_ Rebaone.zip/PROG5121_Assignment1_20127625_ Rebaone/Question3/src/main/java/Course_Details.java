
import java.util.*;
import javax.swing.JOptionPane;

public class Course_Details {
	//DECLARATIONS 
	private String coursename;
	private String lecture;
	private int studentnumber;
	
	//GET & SET
	public void setCourseName(String name) 
        {
		coursename = name;
	}
	
	public void setLecture(String Lecture) 
        {
		lecture = Lecture;
	}
	
	public void setStudentNumber(int number) 
        {
		studentnumber = number;
	}
	String getCourseName() 
        {
		return coursename;
	}
	String getLecture() 
        {
		return lecture;
	}
        int getStudentNumber() 
        {
		return studentnumber;
	}
	
	//ASSIGNING RANDOM VENUES
	static int assignVenue() {
		int venue = 1 + (int)(Math.random() * ((3 - 1) + 1));
	    return venue;
	}

	public static void main(String[] args) {
		//GENERATING METHOD 
		Course_Details coursedetails = new Course_Details();
		Date date = new Date();
		
		char ans;
		String reply;	
		
		do {
		int input = Integer.parseInt( JOptionPane.showInputDialog(
                        "Select from the following to view course the details:"
                        + "\n" +"1) DISD \n2) DIWD \n3) DIDM"));
		
		//SWITCH CASE FOR COURSE SELECTION 
                    switch (input) {
                        case 1:
                            {
                                int venue = assignVenue();
                                coursedetails.setCourseName("Diploma in Software Developemnt");
                                coursedetails.setStudentNumber(35);
                                coursedetails.setLecture("Mr Jones");
                                System.out.println("COURSE REPORT - " + date.toString()+ 
                                        "\n*********************************************\n"
                                        + "COURSE:           " + coursedetails.getCourseName()+"\n"
                                        + "STUDENT NUMBER:   " + coursedetails.getStudentNumber()+"\n"
                                        + "LECTURE:          " + coursedetails.getLecture()+"\n"
                                        + "VENUE:            " + "Venue " + venue +"\n"
                                        + "******************************");
                                break;
                            }
                        case 2:
                            {
                                int venue = assignVenue();
                                coursedetails.setCourseName("Diploma in Web Developement");
                                coursedetails.setStudentNumber(28);
                                coursedetails.setLecture("Mrs Smith");
                                System.out.println("COURSE REPORT - " + date.toString()+ 
                                        "\n*********************************************\n"
                                        + "COURSE:           " + coursedetails.getCourseName()+"\n"
                                        + "STUDENT NUMBER:   " + coursedetails.getStudentNumber()+"\n"
                                        + "LECTURE:          " + coursedetails.getLecture()+"\n"
                                        + "VENUE:            " +  "Venue " + venue + "\n"
                                        + "******************************");
                                break;
                            }
                        case 3:
                            {
                                int venue = assignVenue();
                                coursedetails.setCourseName("Diploma in Data Metrics");
                                coursedetails.setStudentNumber(39);
                                coursedetails.setLecture("Mr Ntsinga");
                                System.out.println("COURSE REPORT - " + date.toString()+ 
                                        "\n*********************************************\n"
                                        + "COURSE:           " + coursedetails.getCourseName()+"\n"
                                        + "STUDENT NUMBER:   " + coursedetails.getStudentNumber()+"\n"
                                        + "LECTURE:          " + coursedetails.getLecture()+"\n"
                                        + "VENUE:            " +  "Venue " + venue +"\n "
                                        + "******************************");
                                break;
                            }
                        default:
                            break;
                    }
		reply = JOptionPane.showInputDialog(null,
                        "Would you like to exit the application? Enter (y) to use exit or any other key to continue ");
		ans = reply.charAt(0);
         //WHILE LOOP WHICH WILL FIND IF Y IS ENTERED
	}while( ans != 'y');
	}

}
