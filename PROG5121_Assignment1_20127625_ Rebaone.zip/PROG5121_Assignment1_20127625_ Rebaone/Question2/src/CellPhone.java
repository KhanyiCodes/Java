
import java.util.*;

import javax.swing.JOptionPane;


public class CellPhone {
	
	public static void main(String[] args) {
		//DECLARATIONS OF NAMES & NETWORKS 
		String name1;
		String name2;
		String name3;
		String network1;
		String network2;
		String network3;
	
		//ARRAY WHICH HOLDS NETWORK PROVIDERS & STARTING NUMBERS FOT EACH NETWORK
		String networkprovider[] = 
                    {"VODACOM network with phone number 072 " , 
                    "MTN network with phone number 083 " , 
                    "CELLC network with phone number 084 "};
		
        
        //RANDOMLY GENERATING NETWORK PROVIDERS 
        Random generator = new Random();
        int randomprovider1 = generator.nextInt(networkprovider.length);
        int randomprovider2 = generator.nextInt(networkprovider.length);
        int randomprovider3 = generator.nextInt(networkprovider.length);
        
        //RANDOMLY GENERATING NUMBERS      
        int randomNumber1 = generator.nextInt(1000);
        int randomNumber2 = generator.nextInt(10000);
        int randomNumber3 = generator.nextInt(1000);
        int randomNumber4 = generator.nextInt(10000);
        int randomNumber5 = generator.nextInt(1000);
        int randomNumber6 = generator.nextInt(10000);
        
        //JOPTION FOR NAMES 
        name1 = JOptionPane.showInputDialog("Enter first name:");
        name2 = JOptionPane.showInputDialog("Enter second name:");
        name3 = JOptionPane.showInputDialog("Enter third name:");
        
         //JOPTION FOR RANDOM NETWORK PROVIDERS ACCORDING TO NAMES
        network1 = networkprovider[randomprovider1];
        network2 = networkprovider[randomprovider2];
        network3 = networkprovider[randomprovider3];
        
        //JOPTION FOR MESSAGE DIALOG WHICH INCLUDES NAMES, NETWORK PROVIDER AND RANDOM NUMBERS
        JOptionPane.showMessageDialog(null,"CELL PHONE NUMBER GENERATOR \n******************************************\n"+
        	 name1 + " will be on the " + network1 + randomNumber1+" - ("+ randomNumber2 + ")\n"+
                 name2 + " will be on the " + network2 + randomNumber3+" - ("+ randomNumber4 + ")\n"+
        	 name3 + " will be on the " + network3 + randomNumber5+" - ("+ randomNumber6 + ")\n");
        
        	
	
    }

}
