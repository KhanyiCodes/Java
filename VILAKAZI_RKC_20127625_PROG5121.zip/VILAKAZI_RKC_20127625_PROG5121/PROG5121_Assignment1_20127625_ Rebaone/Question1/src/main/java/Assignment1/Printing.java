package Assignment1;
import java.util.Scanner;

public class Printing extends CustomerPurchases {
       //DECLARATIONS FOR CALCULATIONS
	private double tax;
	private double commission;
	private double discount;
	private double total;
	 
	//GET & SET METHOD
	public void setTax(double newtax) 
        {
		tax  = newtax * 0.15;		
	}
	
	public void setCommission(float new_commission) 
        {
		commission = new_commission * 0.085;
	}
	
	public void setDiscount(double new_discount)
        {
		discount = new_discount * 0.1;
	}
	
	public void setTotal(double new_total) 
        {
		total = new_total;
	}
	
	
	public double getTax() 
        {
		return tax;
	}
	double getCommission() {
		return commission;
	}
	
        double getDiscount() 
        {
		return discount;
	}
        
        double getTotal() 
        {
		return total;
	}
        
	public static double total(double price, double tax, double discount, float commission) 
        {
		double total;
		total = (price + tax) - (discount + commission);
		return total;
	}
	
	public static void printdetails(int num, 
                                       String name, 
                                       String surname, 
                                       double price, 
                                       int quantity) 
        {	
		System.out.println("CUSTOMER INVOICE");
		System.out.println("****************************");
		System.out.println("CUSTOMER NUMBER:      " + num);
		System.out.println("CUSTOMER FIRST NAME:  " + name);
		System.out.println("CUSTOMER SURNAME:     " + surname);
		System.out.println("PRODUCT PRICE:        R " + price);
		System.out.println("PRODUCT QUANTITY:     " + quantity);
		System.out.println("****************************");
		
	}
	
	public static void customerpurchasereport(double price, 
                                                  double tax, 
                                                  double discount, 
                                                  float commission,
			                          double total) 
        {
		 
		System.out.println("CUSTOMER PURCHASE REPORT");
		System.out.println("*************************");
		System.out.println("PRODUCT PRICE:  R " + price);
		System.out.println("TAX:            R " + tax);
		System.out.println("COMMISION:      R " + commission);
		System.out.println("DISCOUNT:       R " + discount);
		System.out.println("TOTAL:          R " + total);
		System.out.println("*************************");
		System.out.println("Application Complete");
	}

	public static void main(String[] args) 
        {
		// TODO Auto-generated method stub
		
		Printing customerpurchase = new Printing();
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter the customer number >> ");
		customerpurchase.setCustmomernumber(input.nextInt());

		System.out.println("Enter the customer first name >> ");
		customerpurchase.setFirstname(input.next());

		System.out.println("Enter the customer surname >> ");
		customerpurchase.setSurname(input.next());

		System.out.println("Enter the product >> ");
		customerpurchase.setProduct(input.next());

		System.out.println("Enter the product price >> ");
		customerpurchase.setPrice(input.nextDouble());

		System.out.println("Enter the quantity required >> ");
		customerpurchase.setQuantity(input.nextInt());
		
		printdetails(customerpurchase.getCustomernumber(), 
                             customerpurchase.getFirstname(),
		             customerpurchase.getSurname(), 
                             customerpurchase.getPrice(),
			     customerpurchase.getQuantity());
		
		customerpurchase.setTax(customerpurchase.getPrice());
		customerpurchase.setCommission((float) customerpurchase.getPrice());
		customerpurchase.setDiscount(customerpurchase.getPrice());
		
		System.out.println("Would you like to view the product purchase report? Enter (1)" 
				         + " to view the purchase report or any other key to exit.");
		int one;
		one = input.nextInt();
		
		if( one == 1) 
                {
		
		customerpurchasereport(customerpurchase.getPrice(), 
                                       customerpurchase.getTax(), 
                                       customerpurchase.getDiscount(), 
                                       (float) customerpurchase.getCommission(), 
                                       total(customerpurchase.getPrice(), customerpurchase.getTax(),
				       customerpurchase.getDiscount(), 
                                       (float) customerpurchase.getCommission()));
		
		}
		else 
			System.out.println("Thank you for shopping with us");
		
	}

	
}

