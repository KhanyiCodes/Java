package Assignment1;

public class CustomerPurchases {
	//DECLARATIONS FOR INPUTS
	private int customernumber;
	private String firstname;
	private String surname;
	private String product;
	private double price; 
	private int quantity;
	
        //GET & SET METHOD
	public void setCustmomernumber(int num)
        {
		customernumber = num;
	}
        
	public void setFirstname(String name)
        {
		firstname = name;
	}

	public void setSurname(String new_surname) 
        {
		surname = new_surname;
	}
       
	public void setProduct(String new_product) 
        {
		product = new_product;
	}
	
	public void setPrice(double new_price) 
        {
		price = new_price;
	}
	double getPrice()
        {
		return price;
	}
        
	public void setQuantity(int new_quantity) 
        {
		quantity = new_quantity;
	}
	
	
        
        int getCustomernumber() 
        {
		return customernumber;
	}
        
        String getFirstname() 
        {
		return firstname;
	}
        String getSurname() 
        {
		return surname;
	}
        int getQuantity() 
        {
		return quantity;
	}
        String getProduct() 
        {
		return product;
	}
}
