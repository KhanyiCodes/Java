
import java.util.*;

import javax.swing.JOptionPane;


public class CellPhone {
	
	public static void main(String[] args) {
		//DECLARATIONS 4 NAMES & NETWORKS
		String name1;
		String name2;
		String name3;
		String networkA;
		String networkB;
		String networkC;
	
		//ARRAY WHICH CONTAINS NETWORK PROVIDERS & STARTING NUMBERS ACCORDING TO THE NETWORK PROVIDERS 
		String networkprovider[] = 
                    {"VODACOM network with phone number 072 ",
                     "MTN network with phone number 083 ",
                     "CELL C network with phone number 084 "};
		
        
        //RANDOMLY GENERATING NETWORK PROVIDERS & ARRAY WHICH CONTAINS NETWORK PROVIDERS
        Random generator = new Random();
        int randomprovider1 = generator.nextInt(networkprovider.length);
        int randomprovider2 = generator.nextInt(networkprovider.length);
        int randomprovider3 = generator.nextInt(networkprovider.length);
        networkA = networkprovider[randomprovider1];
        networkB = networkprovider[randomprovider2];
        networkC = networkprovider[randomprovider3];
        //RANDOMLY GENERATING NUMBERS          
        int randomNumber1 = generator.nextInt(1000);
        int randomNumber2 = generator.nextInt(10000);
        int randomNumber3 = generator.nextInt(1000);
        int randomNumber4 = generator.nextInt(10000);
        int randomNumber5 = generator.nextInt(1000);
        int randomNumber6 = generator.nextInt(10000);
        
        //JOPTION INPUT DIALOG FOR NAMES 
        name1 = JOptionPane.showInputDialog("Enter first name:");
        name2 = JOptionPane.showInputDialog("Enter second name:");
        name3 = JOptionPane.showInputDialog("Enter third name:");
       
        
        //JOPTION FOR MESSAGE DIALOG WHICH WILL DISPLAY NAMES, NETWORK PROVIDERS & RANDOM NUMBERS
        JOptionPane.showMessageDialog(null,"CELL PHONE NUMBER GENERATOR \n******************************************\n"+
        	 name1 + " will be on the " + networkA + randomNumber1+" - ("+ randomNumber2 + ")\n"+
                 name2 + " will be on the " + networkB + randomNumber3+" - ("+ randomNumber4 + ")\n"+
        	 name3 + " will be on the " + networkC + randomNumber5+" - ("+ randomNumber6 + ")\n", 
                "Network Provider Assignment", JOptionPane.INFORMATION_MESSAGE);
        
        	
	
    }

}
